use Final_Project;

Select * from Ex_Employee_Information;

Delete from Ex_Employee_Information where ExEmployeeId = 9;

Update Ex_Employee_Information set EmployeeId = '123456' where ExEmployeeId ='9';