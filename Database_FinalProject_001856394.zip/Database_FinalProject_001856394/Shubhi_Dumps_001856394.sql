-- MySQL dump 10.13  Distrib 5.7.19, for macos10.12 (x86_64)
--
-- Host: localhost    Database: Final_Project
-- ------------------------------------------------------
-- Server version	5.7.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Audit_Employee_Department_Details`
--

DROP TABLE IF EXISTS `Audit_Employee_Department_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Audit_Employee_Department_Details` (
  `AuditId` int(11) NOT NULL AUTO_INCREMENT,
  `EmployeeId` varchar(6) NOT NULL,
  `DepartmentName` varchar(15) NOT NULL,
  `DepartmentId` varchar(6) NOT NULL,
  `DepartmentType` varchar(20) NOT NULL,
  `DepartmentHead` varchar(60) NOT NULL,
  `DeliveryManager` varchar(60) NOT NULL,
  PRIMARY KEY (`AuditId`),
  UNIQUE KEY `AuditId_UNIQUE` (`AuditId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Audit_Employee_Department_Details`
--

LOCK TABLES `Audit_Employee_Department_Details` WRITE;
/*!40000 ALTER TABLE `Audit_Employee_Department_Details` DISABLE KEYS */;
INSERT INTO `Audit_Employee_Department_Details` VALUES (1,'716194','FSADM2','3','Telecom','Mike Denson','Jimmy Morgan'),(2,'716195','TELSTR','4','Telecom','Mike Denson','Jimmy Morgan'),(3,'716192','FSADM1','1','Banking','Denis Louis','David Philps'),(4,'716193','UKRBWS','2','Finance','Mike Denson','Jimmy Morgan');
/*!40000 ALTER TABLE `Audit_Employee_Department_Details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Audit_Employee_Salary_Details`
--

DROP TABLE IF EXISTS `Audit_Employee_Salary_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Audit_Employee_Salary_Details` (
  `AuditId` int(11) NOT NULL AUTO_INCREMENT,
  `OldBasicSalary` decimal(14,2) NOT NULL,
  `OldTotalCTC` decimal(14,2) NOT NULL,
  `EmployeeId` varchar(6) NOT NULL,
  `SalaryId` varchar(6) NOT NULL,
  `OldMonthlySalary` decimal(14,2) NOT NULL,
  `OldAllowances` decimal(14,2) NOT NULL,
  PRIMARY KEY (`AuditId`),
  UNIQUE KEY `AuditId_UNIQUE` (`AuditId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Audit_Employee_Salary_Details`
--

LOCK TABLES `Audit_Employee_Salary_Details` WRITE;
/*!40000 ALTER TABLE `Audit_Employee_Salary_Details` DISABLE KEYS */;
/*!40000 ALTER TABLE `Audit_Employee_Salary_Details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employee_Company_Information`
--

DROP TABLE IF EXISTS `Employee_Company_Information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee_Company_Information` (
  `EmployeeId` varchar(6) NOT NULL,
  `Department` varchar(15) NOT NULL,
  `DateOfJoining` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Designation` varchar(30) NOT NULL,
  `ProjectAllocationCode` varchar(15) NOT NULL,
  `OfficeLocation` varchar(20) NOT NULL,
  `State` varchar(30) NOT NULL,
  `ZipCode` varchar(5) NOT NULL,
  `OfficeEmailId` varchar(30) NOT NULL,
  `OfficeContactNumber` varchar(10) NOT NULL,
  PRIMARY KEY (`EmployeeId`),
  UNIQUE KEY `EmployeeId_UNIQUE` (`EmployeeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee_Company_Information`
--

LOCK TABLES `Employee_Company_Information` WRITE;
/*!40000 ALTER TABLE `Employee_Company_Information` DISABLE KEYS */;
INSERT INTO `Employee_Company_Information` VALUES ('716192','FSADM1','2009-01-01 05:00:00','System Engineer','BBSYDF','Boston','Massachusetts','02115','Robert_John@Barclays.com','989034789'),('716193','UKRBWS','2012-03-04 05:00:00','Test Engineer','HJKKLO','Boston','Massachusetts','02115','Alisa_Smith@Barclays.com','6578956453');
/*!40000 ALTER TABLE `Employee_Company_Information` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER Audit_delete_Employee AFTER DELETE on Employee_Company_Information
FOR EACH ROW
BEGIN

Insert Into  Ex_Employee_Information(EmployeeId,DateOfLeaving) value(old.EmployeeId,sysdate());

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Employee_Department_Details`
--

DROP TABLE IF EXISTS `Employee_Department_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee_Department_Details` (
  `DepartmentId` varchar(6) NOT NULL,
  `DepartmentName` varchar(15) NOT NULL,
  `DepartmentType` varchar(20) NOT NULL,
  `DepartmenrHead` varchar(60) NOT NULL,
  `DeliveryManager` varchar(60) NOT NULL,
  `Employee_Company_Information_EmployeeId` varchar(6) NOT NULL,
  PRIMARY KEY (`DepartmentId`),
  UNIQUE KEY `DepartmentId_UNIQUE` (`DepartmentId`),
  KEY `fk_Employee Department Details_Employee Company Information_idx` (`Employee_Company_Information_EmployeeId`),
  CONSTRAINT `fk_Employee Department Details_Employee Company Information1` FOREIGN KEY (`Employee_Company_Information_EmployeeId`) REFERENCES `Employee_Company_Information` (`EmployeeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee_Department_Details`
--

LOCK TABLES `Employee_Department_Details` WRITE;
/*!40000 ALTER TABLE `Employee_Department_Details` DISABLE KEYS */;
/*!40000 ALTER TABLE `Employee_Department_Details` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER Audit_Department_Details AFTER DELETE on Employee_Department_Details
FOR EACH ROW
BEGIN

Insert Into  Audit_Employee_Department_Details(EmployeeId,DepartmentName,DepartmentId,DepartmentType,DepartmentHead,DeliveryManager) 
value(old.Employee_Company_Information_EmployeeId,old.DepartmentName,old.DepartmentId,old.DepartmentType,old.DepartmenrHead,old.DeliveryManager);

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Employee_Leave_Details`
--

DROP TABLE IF EXISTS `Employee_Leave_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee_Leave_Details` (
  `LeaveId` varchar(6) NOT NULL,
  `TotalLeaves` int(11) NOT NULL,
  `TotalLeavesDebited` int(11) NOT NULL,
  `AvailableLeaves` int(11) NOT NULL,
  `TotalSickLeaves` int(11) NOT NULL,
  `SickLeavesDebited` int(11) NOT NULL,
  `AvailableSickLeaves` int(11) NOT NULL,
  `Employee_Company_Information_EmployeeId` varchar(6) NOT NULL,
  PRIMARY KEY (`LeaveId`),
  UNIQUE KEY `LeaveId_UNIQUE` (`LeaveId`),
  KEY `fk_Employee_Leave_Details_Employee_Company_Information1_idx` (`Employee_Company_Information_EmployeeId`),
  CONSTRAINT `fk_Employee_Leave_Details_Employee_Company_Information1` FOREIGN KEY (`Employee_Company_Information_EmployeeId`) REFERENCES `Employee_Company_Information` (`EmployeeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee_Leave_Details`
--

LOCK TABLES `Employee_Leave_Details` WRITE;
/*!40000 ALTER TABLE `Employee_Leave_Details` DISABLE KEYS */;
/*!40000 ALTER TABLE `Employee_Leave_Details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employee_Performance_Information`
--

DROP TABLE IF EXISTS `Employee_Performance_Information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee_Performance_Information` (
  `PerformanceId` varchar(6) NOT NULL,
  `QuarterStartDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `QuarterEndDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Rating` varchar(10) NOT NULL,
  `EvaluationManager` varchar(60) NOT NULL,
  `ApprovalManager` varchar(60) NOT NULL,
  `Employee_Company_Information_EmployeeId` varchar(6) NOT NULL,
  PRIMARY KEY (`PerformanceId`),
  UNIQUE KEY `PerformanceId_UNIQUE` (`PerformanceId`),
  KEY `fk_Employee_Performance_Information_Employee_Company_Inform_idx` (`Employee_Company_Information_EmployeeId`),
  CONSTRAINT `fk_Employee_Performance_Information_Employee_Company_Informat1` FOREIGN KEY (`Employee_Company_Information_EmployeeId`) REFERENCES `Employee_Company_Information` (`EmployeeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee_Performance_Information`
--

LOCK TABLES `Employee_Performance_Information` WRITE;
/*!40000 ALTER TABLE `Employee_Performance_Information` DISABLE KEYS */;
/*!40000 ALTER TABLE `Employee_Performance_Information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employee_Personal_Information`
--

DROP TABLE IF EXISTS `Employee_Personal_Information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee_Personal_Information` (
  `EmployeePersonalInformationId` varchar(6) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `MiddleName` varchar(20) DEFAULT NULL,
  `LastName` varchar(20) NOT NULL,
  `DateOfBirth` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `MobileNumber` varchar(10) NOT NULL,
  `HomeNumber` varchar(10) NOT NULL,
  `City` varchar(20) NOT NULL,
  `State` varchar(30) NOT NULL,
  `ZipCode` varchar(5) NOT NULL,
  `Street` varchar(30) DEFAULT NULL,
  `Gender` varchar(45) NOT NULL,
  `MaritialStatus` varchar(15) DEFAULT NULL,
  `Employee_Company_Information_EmployeeId` varchar(6) NOT NULL,
  PRIMARY KEY (`EmployeePersonalInformationId`),
  UNIQUE KEY `EmployeeId_UNIQUE` (`EmployeePersonalInformationId`),
  UNIQUE KEY `MobileNumber_UNIQUE` (`MobileNumber`),
  KEY `fk_Employee_Personal_Information_Employee_Company_Informati_idx` (`Employee_Company_Information_EmployeeId`),
  CONSTRAINT `fk_Employee_Personal_Information_Employee_Company_Information1` FOREIGN KEY (`Employee_Company_Information_EmployeeId`) REFERENCES `Employee_Company_Information` (`EmployeeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee_Personal_Information`
--

LOCK TABLES `Employee_Personal_Information` WRITE;
/*!40000 ALTER TABLE `Employee_Personal_Information` DISABLE KEYS */;
/*!40000 ALTER TABLE `Employee_Personal_Information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employee_Previous_Work_Experience`
--

DROP TABLE IF EXISTS `Employee_Previous_Work_Experience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee_Previous_Work_Experience` (
  `PreviousWorkExpId` varchar(6) NOT NULL,
  `EmployerName` varchar(30) NOT NULL,
  `Duration` varchar(15) NOT NULL,
  `CompanyLocation` varchar(20) NOT NULL,
  `StartDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `EndDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ComapnyContactNumber` varchar(10) NOT NULL,
  `Employee_Company_Information_EmployeeId` varchar(6) NOT NULL,
  PRIMARY KEY (`PreviousWorkExpId`),
  UNIQUE KEY `PreviousWorkExpId_UNIQUE` (`PreviousWorkExpId`),
  KEY `fk_Employee_Previous_Work_Experience_Employee_Company_Infor_idx` (`Employee_Company_Information_EmployeeId`),
  CONSTRAINT `fk_Employee_Previous_Work_Experience_Employee_Company_Informa1` FOREIGN KEY (`Employee_Company_Information_EmployeeId`) REFERENCES `Employee_Company_Information` (`EmployeeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee_Previous_Work_Experience`
--

LOCK TABLES `Employee_Previous_Work_Experience` WRITE;
/*!40000 ALTER TABLE `Employee_Previous_Work_Experience` DISABLE KEYS */;
/*!40000 ALTER TABLE `Employee_Previous_Work_Experience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employee_Salary_Details`
--

DROP TABLE IF EXISTS `Employee_Salary_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee_Salary_Details` (
  `SalaryId` varchar(6) NOT NULL,
  `MonthlySalary` decimal(14,2) NOT NULL DEFAULT '0.00',
  `SalaryCurrency` varchar(5) NOT NULL,
  `SalaryMonth` varchar(3) NOT NULL,
  `TaxDeductions` decimal(14,2) NOT NULL DEFAULT '0.00',
  `EmiDeductions` decimal(14,2) NOT NULL DEFAULT '0.00',
  `BasicSalary` decimal(14,2) NOT NULL DEFAULT '0.00',
  `Allowances` decimal(14,2) NOT NULL DEFAULT '0.00',
  `TotalCTC` decimal(14,2) NOT NULL DEFAULT '0.00',
  `Employee_Company_Information_EmployeeId` varchar(6) NOT NULL,
  PRIMARY KEY (`SalaryId`),
  UNIQUE KEY `SalaryId_UNIQUE` (`SalaryId`),
  KEY `fk_Employee_Salary_Details_Employee_Company_Information1_idx` (`Employee_Company_Information_EmployeeId`),
  CONSTRAINT `fk_Employee_Salary_Details_Employee_Company_Information1` FOREIGN KEY (`Employee_Company_Information_EmployeeId`) REFERENCES `Employee_Company_Information` (`EmployeeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee_Salary_Details`
--

LOCK TABLES `Employee_Salary_Details` WRITE;
/*!40000 ALTER TABLE `Employee_Salary_Details` DISABLE KEYS */;
/*!40000 ALTER TABLE `Employee_Salary_Details` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER Audit_Increment_Details AFTER UPDATE on Employee_Salary_Details
FOR EACH ROW
BEGIN

Insert Into  Audit_Employee_Salary_Details(OldBasicSalary,OldTotalCTC,EmployeeId,SalaryId,OldMonthlySalary,OldAllowances) 
value(old.BasicSalary,old.TotalCTC,old.Employee_Company_Information_EmployeeId,old.SalaryId,old.MonthlySalary,old.Allowances);

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Employee_Timesheet_Information`
--

DROP TABLE IF EXISTS `Employee_Timesheet_Information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee_Timesheet_Information` (
  `TimeSheetId` varchar(6) NOT NULL,
  `TotalHours` varchar(5) NOT NULL,
  `TaskStartDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TaskEndDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TaskDescription` varchar(100) NOT NULL,
  `ProjectDetails` varchar(15) NOT NULL,
  `ManagerName` varchar(60) NOT NULL,
  `Employee_Company_Information_EmployeeId` varchar(6) NOT NULL,
  PRIMARY KEY (`TimeSheetId`),
  UNIQUE KEY `TimeSheetId_UNIQUE` (`TimeSheetId`),
  KEY `fk_Employee_Timesheet_Information_Employee_Company_Informat_idx` (`Employee_Company_Information_EmployeeId`),
  CONSTRAINT `fk_Employee_Timesheet_Information_Employee_Company_Information1` FOREIGN KEY (`Employee_Company_Information_EmployeeId`) REFERENCES `Employee_Company_Information` (`EmployeeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee_Timesheet_Information`
--

LOCK TABLES `Employee_Timesheet_Information` WRITE;
/*!40000 ALTER TABLE `Employee_Timesheet_Information` DISABLE KEYS */;
/*!40000 ALTER TABLE `Employee_Timesheet_Information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ex_Employee_Information`
--

DROP TABLE IF EXISTS `Ex_Employee_Information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ex_Employee_Information` (
  `ExEmployeeId` int(11) NOT NULL AUTO_INCREMENT,
  `EmployeeId` varchar(6) NOT NULL,
  `DateOfLeaving` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ExEmployeeId`),
  UNIQUE KEY `ExEmployeeId_UNIQUE` (`ExEmployeeId`),
  UNIQUE KEY `EmployeeId_UNIQUE` (`EmployeeId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ex_Employee_Information`
--

LOCK TABLES `Ex_Employee_Information` WRITE;
/*!40000 ALTER TABLE `Ex_Employee_Information` DISABLE KEYS */;
INSERT INTO `Ex_Employee_Information` VALUES (9,'716194','2017-12-13 23:23:38');
/*!40000 ALTER TABLE `Ex_Employee_Information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Project_Allocation_Details`
--

DROP TABLE IF EXISTS `Project_Allocation_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Project_Allocation_Details` (
  `ProjectCode` varchar(6) NOT NULL,
  `StartDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `EndDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Employee_Department_Details_DepartmentId` varchar(6) NOT NULL,
  `Employee_Company_Information_EmployeeId` varchar(6) NOT NULL,
  PRIMARY KEY (`ProjectCode`),
  UNIQUE KEY `ProjectCode_UNIQUE` (`ProjectCode`),
  KEY `fk_Project Allocation Details_Employee Department Details1_idx` (`Employee_Department_Details_DepartmentId`),
  KEY `fk_Project_Allocation_Details_Employee_Company_Information1_idx` (`Employee_Company_Information_EmployeeId`),
  CONSTRAINT `fk_Project Allocation Details_Employee Department Details1` FOREIGN KEY (`Employee_Department_Details_DepartmentId`) REFERENCES `Employee_Department_Details` (`DepartmentId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Project_Allocation_Details_Employee_Company_Information1` FOREIGN KEY (`Employee_Company_Information_EmployeeId`) REFERENCES `Employee_Company_Information` (`EmployeeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Project_Allocation_Details`
--

LOCK TABLES `Project_Allocation_Details` WRITE;
/*!40000 ALTER TABLE `Project_Allocation_Details` DISABLE KEYS */;
/*!40000 ALTER TABLE `Project_Allocation_Details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `employee_info`
--

DROP TABLE IF EXISTS `employee_info`;
/*!50001 DROP VIEW IF EXISTS `employee_info`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `employee_info` AS SELECT 
 1 AS `Employee_Id`,
 1 AS `First_Name`,
 1 AS `Middle_Name`,
 1 AS `Last_Name`,
 1 AS `Date_Of_Birth`,
 1 AS `Home_Number`,
 1 AS `Gender`,
 1 AS `Maritial_Status`,
 1 AS `Department`,
 1 AS `Joining_Date`,
 1 AS `Designation`,
 1 AS `Project_Code`,
 1 AS `Email_Id`,
 1 AS `Location`,
 1 AS `Ratings`,
 1 AS `Evaluation_Manager`,
 1 AS `Approval_Manager`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `project_timesheet_info`
--

DROP TABLE IF EXISTS `project_timesheet_info`;
/*!50001 DROP VIEW IF EXISTS `project_timesheet_info`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `project_timesheet_info` AS SELECT 
 1 AS `Employee_Id`,
 1 AS `Time_Sheet_Id`,
 1 AS `Project_Allocated`,
 1 AS `Project_StartDate`,
 1 AS `Project_EndDate`,
 1 AS `Department`,
 1 AS `Total_Working_Hours_Daily`,
 1 AS `Task_StartDate`,
 1 AS `Task_EndDate`,
 1 AS `Task`,
 1 AS `Manager_Name`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `employee_info`
--

/*!50001 DROP VIEW IF EXISTS `employee_info`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `employee_info` AS select `employee_company_information`.`EmployeeId` AS `Employee_Id`,`employee_personal_information`.`FirstName` AS `First_Name`,`employee_personal_information`.`MiddleName` AS `Middle_Name`,`employee_personal_information`.`LastName` AS `Last_Name`,`employee_personal_information`.`DateOfBirth` AS `Date_Of_Birth`,`employee_personal_information`.`HomeNumber` AS `Home_Number`,`employee_personal_information`.`Gender` AS `Gender`,`employee_personal_information`.`MaritialStatus` AS `Maritial_Status`,`employee_company_information`.`Department` AS `Department`,`employee_company_information`.`DateOfJoining` AS `Joining_Date`,`employee_company_information`.`Designation` AS `Designation`,`employee_company_information`.`ProjectAllocationCode` AS `Project_Code`,`employee_company_information`.`OfficeEmailId` AS `Email_Id`,`employee_company_information`.`OfficeLocation` AS `Location`,`employee_performance_information`.`Rating` AS `Ratings`,`employee_performance_information`.`EvaluationManager` AS `Evaluation_Manager`,`employee_performance_information`.`ApprovalManager` AS `Approval_Manager` from ((`employee_personal_information` join `employee_company_information` on((`employee_company_information`.`EmployeeId` = `employee_personal_information`.`Employee_Company_Information_EmployeeId`))) join `employee_performance_information` on((`employee_company_information`.`EmployeeId` = `employee_performance_information`.`Employee_Company_Information_EmployeeId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `project_timesheet_info`
--

/*!50001 DROP VIEW IF EXISTS `project_timesheet_info`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `project_timesheet_info` AS select `project_allocation_details`.`Employee_Company_Information_EmployeeId` AS `Employee_Id`,`employee_timesheet_information`.`TimeSheetId` AS `Time_Sheet_Id`,`project_allocation_details`.`ProjectCode` AS `Project_Allocated`,`project_allocation_details`.`StartDate` AS `Project_StartDate`,`project_allocation_details`.`EndDate` AS `Project_EndDate`,`project_allocation_details`.`Employee_Department_Details_DepartmentId` AS `Department`,`employee_timesheet_information`.`TotalHours` AS `Total_Working_Hours_Daily`,`employee_timesheet_information`.`TaskStartDate` AS `Task_StartDate`,`employee_timesheet_information`.`TaskEndDate` AS `Task_EndDate`,`employee_timesheet_information`.`TaskDescription` AS `Task`,`employee_timesheet_information`.`ManagerName` AS `Manager_Name` from (`project_allocation_details` join `employee_timesheet_information` on((`project_allocation_details`.`Employee_Company_Information_EmployeeId` = `employee_timesheet_information`.`Employee_Company_Information_EmployeeId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-13 19:02:21
