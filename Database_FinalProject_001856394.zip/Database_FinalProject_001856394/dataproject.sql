use Final_Project;

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema Final_Project
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Final_Project` DEFAULT CHARACTER SET utf8 ;
USE `Final_Project` ;

-- -----------------------------------------------------
-- Table `Final_Project`.`Employee_Company_Information`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Final_Project`.`Employee_Company_Information` (
  `EmployeeId` VARCHAR(6) NOT NULL,
  `Department` VARCHAR(15) NOT NULL,
  `DateOfJoining` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Designation` VARCHAR(30) NOT NULL,
  `ProjectAllocationCode` VARCHAR(15) NOT NULL,
  `OfficeLocation` VARCHAR(20) NOT NULL,
  `State` VARCHAR(30) NOT NULL,
  `ZipCode` VARCHAR(5) NOT NULL,
  `OfficeEmailId` VARCHAR(30) NOT NULL,
  `OfficeContactNumber` VARCHAR(10) NOT NULL,
  UNIQUE INDEX `EmployeeId_UNIQUE` (`EmployeeId` ASC),
  PRIMARY KEY (`EmployeeId`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Final_Project`.`Employee_Personal_Information`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Final_Project`.`Employee_Personal_Information` (
  `EmployeePersonalInformationId` VARCHAR(6) NOT NULL,
  `FirstName` VARCHAR(20) NOT NULL,
  `MiddleName` VARCHAR(20) NULL,
  `LastName` VARCHAR(20) NOT NULL,
  `DateOfBirth` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `MobileNumber` VARCHAR(10) NOT NULL,
  `HomeNumber` VARCHAR(10) NOT NULL,
  `City` VARCHAR(20) NOT NULL,
  `State` VARCHAR(30) NOT NULL,
  `ZipCode` VARCHAR(5) NOT NULL,
  `Street` VARCHAR(30) NULL,
  `Gender` VARCHAR(45) NOT NULL,
  `MaritialStatus` VARCHAR(15) NULL,
  `Employee_Company_Information_EmployeeId` VARCHAR(6) NOT NULL,
  PRIMARY KEY (`EmployeePersonalInformationId`),
  UNIQUE INDEX `EmployeeId_UNIQUE` (`EmployeePersonalInformationId` ASC),
  UNIQUE INDEX `MobileNumber_UNIQUE` (`MobileNumber` ASC),
  INDEX `fk_Employee_Personal_Information_Employee_Company_Informati_idx` (`Employee_Company_Information_EmployeeId` ASC),
  CONSTRAINT `fk_Employee_Personal_Information_Employee_Company_Information1`
    FOREIGN KEY (`Employee_Company_Information_EmployeeId`)
    REFERENCES `Final_Project`.`Employee_Company_Information` (`EmployeeId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Final_Project`.`Employee_Timesheet_Information`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Final_Project`.`Employee_Timesheet_Information` (
  `TimeSheetId` VARCHAR(6) NOT NULL,
  `TotalHours` VARCHAR(5) NOT NULL,
  `TaskStartDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TaskEndDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TaskDescription` VARCHAR(100) NOT NULL,
  `ProjectDetails` VARCHAR(15) NOT NULL,
  `ManagerName` VARCHAR(60) NOT NULL,
  `Employee_Company_Information_EmployeeId` VARCHAR(6) NOT NULL,
  PRIMARY KEY (`TimeSheetId`),
  UNIQUE INDEX `TimeSheetId_UNIQUE` (`TimeSheetId` ASC),
  INDEX `fk_Employee_Timesheet_Information_Employee_Company_Informat_idx` (`Employee_Company_Information_EmployeeId` ASC),
  CONSTRAINT `fk_Employee_Timesheet_Information_Employee_Company_Information1`
    FOREIGN KEY (`Employee_Company_Information_EmployeeId`)
    REFERENCES `Final_Project`.`Employee_Company_Information` (`EmployeeId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Final_Project`.`Employee_Leave_Details`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Final_Project`.`Employee_Leave_Details` (
  `LeaveId` VARCHAR(6) NOT NULL,
  `TotalLeaves` INT(11) NOT NULL,
  `TotalLeavesDebited` INT(11) NOT NULL,
  `AvailableLeaves` INT(11) NOT NULL,
  `TotalSickLeaves` INT(11) NOT NULL,
  `SickLeavesDebited` INT(11) NOT NULL,
  `AvailableSickLeaves` INT(11) NOT NULL,
  `Employee_Company_Information_EmployeeId` VARCHAR(6) NOT NULL,
  PRIMARY KEY (`LeaveId`),
  UNIQUE INDEX `LeaveId_UNIQUE` (`LeaveId` ASC),
  INDEX `fk_Employee_Leave_Details_Employee_Company_Information1_idx` (`Employee_Company_Information_EmployeeId` ASC),
  CONSTRAINT `fk_Employee_Leave_Details_Employee_Company_Information1`
    FOREIGN KEY (`Employee_Company_Information_EmployeeId`)
    REFERENCES `Final_Project`.`Employee_Company_Information` (`EmployeeId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


CREATE TABLE IF NOT EXISTS `Final_Project`.`Audit_Employee_Salary_Details` (
  `AuditId` INT NOT NULL AUTO_INCREMENT,
  `OldBasicSalary` DECIMAL(14,2) NOT NULL,
  `OldTotalCTC` DECIMAL(14,2) NOT NULL,
  `EmployeeId` VARCHAR(6) NOT NULL,
  `SalaryId` VARCHAR(6) NOT NULL,
  `OldMonthlySalary` DECIMAL(14,2) NOT NULL,
  `OldAllowances` DECIMAL(14,2) NOT NULL,
  PRIMARY KEY (`AuditId`),
  UNIQUE INDEX `AuditId_UNIQUE` (`AuditId` ASC))
ENGINE = InnoDB;

ALTER TABLE Audit_Employee_Salary_Details AUTO_INCREMENT= 1;

CREATE TABLE IF NOT EXISTS `Final_Project`.`Audit_Employee_Department_Details` (
  `AuditId` INT NOT NULL AUTO_INCREMENT,
  `EmployeeId` VARCHAR(6) NOT NULL,
  `DepartmentName` VARCHAR(15) NOT NULL,
  `DepartmentId` VARCHAR(6) NOT NULL,
  `DepartmentType` VARCHAR(20) NOT NULL,
  `DepartmentHead` VARCHAR(60) NOT NULL,
  `DeliveryManager` VARCHAR(60) NOT NULL,
  PRIMARY KEY (`AuditId`),
  UNIQUE INDEX `AuditId_UNIQUE` (`AuditId` ASC))
ENGINE = InnoDB;


ALTER TABLE Audit_Employee_Department_Details AUTO_INCREMENT= 1;



-- -----------------------------------------------------
-- Table `Final_Project`.`Employee_Department_Details`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Final_Project`.`Employee_Department_Details` (
  `DepartmentId` VARCHAR(6) NOT NULL,
  `DepartmentName` VARCHAR(15) NOT NULL,
  `DepartmentType` VARCHAR(20) NOT NULL,
  `DepartmenrHead` VARCHAR(60) NOT NULL,
  `DeliveryManager` VARCHAR(60) NOT NULL,
  `Employee_Company_Information_EmployeeId` VARCHAR(6) NOT NULL,
  PRIMARY KEY (`DepartmentId`),
  UNIQUE INDEX `DepartmentId_UNIQUE` (`DepartmentId` ASC),
  INDEX `fk_Employee Department Details_Employee Company Information_idx` (`Employee_Company_Information_EmployeeId` ASC),
  CONSTRAINT `fk_Employee Department Details_Employee Company Information1`
    FOREIGN KEY (`Employee_Company_Information_EmployeeId`)
    REFERENCES `Final_Project`.`Employee_Company_Information` (`EmployeeId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Final_Project`.`Employee_Performance_Information`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Final_Project`.`Employee_Performance_Information` (
  `PerformanceId` VARCHAR(6) NOT NULL,
  `QuarterStartDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `QuarterEndDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Rating` VARCHAR(10) NOT NULL,
  `EvaluationManager` VARCHAR(60) NOT NULL,
  `ApprovalManager` VARCHAR(60) NOT NULL,
  `Employee_Company_Information_EmployeeId` VARCHAR(6) NOT NULL,
  PRIMARY KEY (`PerformanceId`),
  UNIQUE INDEX `PerformanceId_UNIQUE` (`PerformanceId` ASC),
  INDEX `fk_Employee_Performance_Information_Employee_Company_Inform_idx` (`Employee_Company_Information_EmployeeId` ASC),
  CONSTRAINT `fk_Employee_Performance_Information_Employee_Company_Informat1`
    FOREIGN KEY (`Employee_Company_Information_EmployeeId`)
    REFERENCES `Final_Project`.`Employee_Company_Information` (`EmployeeId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Final_Project`.`Employee_Salary_Details`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Final_Project`.`Employee_Salary_Details` (
  `SalaryId` VARCHAR(6) NOT NULL,
  `MonthlySalary` DECIMAL(14,2) NOT NULL default 0,
  `SalaryCurrency` VARCHAR(5) NOT NULL,
  `SalaryMonth` VARCHAR(3) NOT NULL,
  `TaxDeductions` DECIMAL(14,2) NOT NULL default 0,
  `EmiDeductions` DECIMAL(14,2) NOT NULL default 0,
  `BasicSalary` DECIMAL(14,2) NOT NULL default 0,
  `Allowances` DECIMAL(14,2) NOT NULL default 0,
  `TotalCTC` DECIMAL(14,2) NOT NULL default 0,
  `Employee_Company_Information_EmployeeId` VARCHAR(6) NOT NULL,
  UNIQUE INDEX `SalaryId_UNIQUE` (`SalaryId` ASC),
  PRIMARY KEY (`SalaryId`),
  INDEX `fk_Employee_Salary_Details_Employee_Company_Information1_idx` (`Employee_Company_Information_EmployeeId` ASC),
  CONSTRAINT `fk_Employee_Salary_Details_Employee_Company_Information1`
    FOREIGN KEY (`Employee_Company_Information_EmployeeId`)
    REFERENCES `Final_Project`.`Employee_Company_Information` (`EmployeeId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Final_Project`.`Employee_Previous_Work_Experience`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Final_Project`.`Employee_Previous_Work_Experience` (
  `PreviousWorkExpId` VARCHAR(6) NOT NULL,
  `EmployerName` VARCHAR(30) NOT NULL,
  `Duration` VARCHAR(15) NOT NULL,
  `CompanyLocation` VARCHAR(20) NOT NULL,
  `StartDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `EndDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ComapnyContactNumber` VARCHAR(10) NOT NULL,
  `Employee_Company_Information_EmployeeId` VARCHAR(6) NOT NULL,
  PRIMARY KEY (`PreviousWorkExpId`),
  UNIQUE INDEX `PreviousWorkExpId_UNIQUE` (`PreviousWorkExpId` ASC),
  INDEX `fk_Employee_Previous_Work_Experience_Employee_Company_Infor_idx` (`Employee_Company_Information_EmployeeId` ASC),
  CONSTRAINT `fk_Employee_Previous_Work_Experience_Employee_Company_Informa1`
    FOREIGN KEY (`Employee_Company_Information_EmployeeId`)
    REFERENCES `Final_Project`.`Employee_Company_Information` (`EmployeeId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Final_Project`.`Project_Allocation_Details`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Final_Project`.`Project_Allocation_Details` (
  `ProjectCode` VARCHAR(6) NOT NULL,
  `StartDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `EndDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Employee_Department_Details_DepartmentId` VARCHAR(6) NOT NULL,
  `Employee_Company_Information_EmployeeId` VARCHAR(6) NOT NULL,
  UNIQUE INDEX `ProjectCode_UNIQUE` (`ProjectCode` ASC),
  PRIMARY KEY (`ProjectCode`),
  INDEX `fk_Project Allocation Details_Employee Department Details1_idx` (`Employee_Department_Details_DepartmentId` ASC),
  INDEX `fk_Project_Allocation_Details_Employee_Company_Information1_idx` (`Employee_Company_Information_EmployeeId` ASC),
  CONSTRAINT `fk_Project Allocation Details_Employee Department Details1`
    FOREIGN KEY (`Employee_Department_Details_DepartmentId`)
    REFERENCES `Final_Project`.`Employee_Department_Details` (`DepartmentId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Project_Allocation_Details_Employee_Company_Information1`
    FOREIGN KEY (`Employee_Company_Information_EmployeeId`)
    REFERENCES `Final_Project`.`Employee_Company_Information` (`EmployeeId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Final_Project`.`Ex_Employee_Information`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Final_Project`.`Ex_Employee_Information` (
  `ExEmployeeId` INT NOT NULL AUTO_INCREMENT,
  `EmployeeId` VARCHAR(6) NOT NULL,
  `DateOfLeaving` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ExEmployeeId`),
  UNIQUE INDEX `ExEmployeeId_UNIQUE` (`ExEmployeeId` ASC),
  UNIQUE INDEX `EmployeeId_UNIQUE` (`EmployeeId` ASC))
ENGINE = InnoDB;

ALTER TABLE Ex_Employee_Information AUTO_INCREMENT= 1;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


-- Drop statements for all table

-- drop table Ex_Employee_Information;
-- drop table Employee_Leave_Details;
-- drop table Employee_Personal_Information;
-- drop table Employee_Performance_Information;
-- drop table Employee_Salary_Details;
-- drop table Employee_Timesheet_Information;
-- drop table Employee_Previous_Work_Experience;
-- drop table Project_Allocation_Details;
-- drop table Employee_Department_Details;
-- drop table Employee_Company_Information;
-- Drop table Audit_Employee_Salary_Details;

-- Insert statements for Employee_Company_Information

use Final_Project;

INSERT INTO Employee_Company_Information
(EmployeeId,
Department,
DateOfJoining,
Designation,
ProjectAllocationCode,
OfficeLocation,
State,
ZipCode,
OfficeEmailId,
OfficeContactNumber)
VALUES
('716192','FSADM1','2009-01-01','System Engineer','BBSYDF','Boston','Massachusetts','02115','Robert_John@Barclays.com','989034789');


INSERT INTO Employee_Company_Information
(EmployeeId,
Department,
DateOfJoining,
Designation,
ProjectAllocationCode,
OfficeLocation,
State,
ZipCode,
OfficeEmailId,
OfficeContactNumber)
VALUES
('716193','UKRBWS','2012-03-04','Test Engineer','HJKKLO','Boston','Massachusetts','02115','Alisa_Smith@Barclays.com','6578956453');

INSERT INTO Employee_Company_Information
(EmployeeId,
Department,
DateOfJoining,
Designation,
ProjectAllocationCode,
OfficeLocation,
State,
ZipCode,
OfficeEmailId,
OfficeContactNumber)
VALUES
('716194','FSADM2','2014-01-01','System Engineer','SVGFRS','Boston','Massachusetts','02115','Andrew_Coyne@Barclays.com','6567898777');

INSERT INTO Employee_Company_Information
(EmployeeId,
Department,
DateOfJoining,
Designation,
ProjectAllocationCode,
OfficeLocation,
State,
ZipCode,
OfficeEmailId,
OfficeContactNumber)
VALUES
('716195','TELSTR','2012-03-01','Business Analyst','HJKLGF','Boston','Massachusetts','02115','Karin_Jones@Barclays.com','6745423444');

Select * from Employee_Company_Information;

-- Insert Statements for Ex_Employee_Information

INSERT INTO Ex_Employee_Information
(ExEmployeeId,
EmployeeId,
DateOfLeaving)
VALUES
('654539','124345','2013-08-05 18:19:03');

INSERT INTO Ex_Employee_Information
(ExEmployeeId,
EmployeeId,
DateOfLeaving)
VALUES
('235672','678543','2014-09-05 18:19:03');

INSERT INTO Ex_Employee_Information
(ExEmployeeId,
EmployeeId,
DateOfLeaving)
VALUES
('785432','430987','2016-03-06 18:19:03');


INSERT INTO Ex_Employee_Information
(ExEmployeeId,
EmployeeId,
DateOfLeaving)
VALUES
('897666','342312','2018-03-07 18:19:03');

select * from Ex_Employee_Information;

-- Insert Statements for Employee_Timesheet_Information

INSERT INTO Employee_Timesheet_Information
(TimeSheetId,
TotalHours,
TaskStartDate,
TaskEndDate,
TaskDescription,
ProjectDetails,
ManagerName,
Employee_Company_Information_EmployeeId)
VALUES
('1','03:50','2017-01-01 18:19:03','2017-03-31','Test Case Preparation','BBSDFE','Steven Louis','716192');

INSERT INTO Employee_Timesheet_Information
(TimeSheetId,
TotalHours,
TaskStartDate,
TaskEndDate,
TaskDescription,
ProjectDetails,
ManagerName,
Employee_Company_Information_EmployeeId)
VALUES
('2','08:50','2017-01-01 18:19:03','2017-03-31','Sanity Testing','BBSDF2','Mike Denson','716193');

INSERT INTO Employee_Timesheet_Information
(TimeSheetId,
TotalHours,
TaskStartDate,
TaskEndDate,
TaskDescription,
ProjectDetails,
ManagerName,
Employee_Company_Information_EmployeeId)
VALUES
('3','07:30','2017-01-01 18:19:03','2017-03-31','Requirement Analysis','BBSDF2','Mike Denson','716194');

INSERT INTO Employee_Timesheet_Information
(TimeSheetId,
TotalHours,
TaskStartDate,
TaskEndDate,
TaskDescription,
ProjectDetails,
ManagerName,
Employee_Company_Information_EmployeeId)
VALUES
('4','11:30','2017-01-01 18:19:03','2017-03-31','Development of Application Module','BBSDF2','Mike Denson','716195');

select * from Employee_Timesheet_Information;

-- Insert Statements for Employee_Performance_Information

INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,
Employee_Company_Information_EmployeeId)
VALUES
('1','2017-01-01','2017-03-31','A+','David Philps','Denis Louis','716192');

INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,
Employee_Company_Information_EmployeeId)
VALUES
('2','2017-04-01','2017-06-30','A','David Philps','Denis Louis','716192');

INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,
Employee_Company_Information_EmployeeId)
VALUES
('3','2017-07-01','2017-09-30','A+','David Philps','Denis Louis','716192');


INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,Employee_Company_Information_EmployeeId)
VALUES
('4','2017-01-01','2017-03-31','B','Jimmy Morgan','Mike Denson','716193');

INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,
Employee_Company_Information_EmployeeId)
VALUES
('5','2017-04-01','2017-06-30','A','Jimmy Morgan','Mike Denson','716193');

INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,
Employee_Company_Information_EmployeeId)
VALUES
('6','2017-07-01','2017-09-30','A+','Jimmy Morgan','Mike Denson','716193');

INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,Employee_Company_Information_EmployeeId)
VALUES
('7','2017-01-01','2017-03-31','B+','Jimmy Morgan','Mike Denson','716194');

INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,Employee_Company_Information_EmployeeId)
VALUES
('8','2017-04-01','2017-06-30','A+','Jimmy Morgan','Mike Denson','716194');

INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,Employee_Company_Information_EmployeeId)
VALUES
('9','2017-07-01','2017-09-30','A','Jimmy Morgan','Mike Denson','716194');

INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,Employee_Company_Information_EmployeeId)
VALUES
('10','2017-01-01','2017-03-31','A+','Jimmy Morgan','Mike Denson','716195');

INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,Employee_Company_Information_EmployeeId)
VALUES
('11','2017-04-01','2017-06-30','A+','Jimmy Morgan','Mike Denson','716195');

INSERT INTO Employee_Performance_Information
(PerformanceId,
QuarterStartDate,
QuarterEndDate,
Rating,
EvaluationManager,
ApprovalManager,Employee_Company_Information_EmployeeId)
VALUES
('12','2017-07-01','2017-09-30','C','Jimmy Morgan','Mike Denson','716195');

Select * from Employee_Performance_Information;


-- Insert Statements for Employee_Leave_Details


INSERT INTO Employee_Leave_Details
(LeaveId,
TotalLeaves,
TotalLeavesDebited,
AvailableLeaves,
TotalSickLeaves,
SickLeavesDebited,
AvailableSickLeaves,Employee_Company_Information_EmployeeId)
VALUES
('1',25,13,12,12,7,5,'716192');

INSERT INTO Employee_Leave_Details
(LeaveId,
TotalLeaves,
TotalLeavesDebited,
AvailableLeaves,
TotalSickLeaves,
SickLeavesDebited,
AvailableSickLeaves,Employee_Company_Information_EmployeeId)
VALUES
('2',25,17,8,12,2,10,'716193');

INSERT INTO Employee_Leave_Details
(LeaveId,
TotalLeaves,
TotalLeavesDebited,
AvailableLeaves,
TotalSickLeaves,
SickLeavesDebited,
AvailableSickLeaves,Employee_Company_Information_EmployeeId)
VALUES
('3',25,23,2,12,12,0,'716194');

INSERT INTO Employee_Leave_Details
(LeaveId,
TotalLeaves,
TotalLeavesDebited,
AvailableLeaves,
TotalSickLeaves,
SickLeavesDebited,
AvailableSickLeaves,Employee_Company_Information_EmployeeId)
VALUES
('4',25,20,5,12,11,1,'716195');

Select * from Employee_Leave_Details;

-- Insert Statements for Employee_Salary_Details

-- Select * from Employee_Salary_Details;

INSERT INTO Employee_Salary_Details
(SalaryId,
MonthlySalary,
SalaryCurrency,
SalaryMonth,
TaxDeductions,
EmiDeductions,
BasicSalary,
Allowances,
TotalCTC,Employee_Company_Information_EmployeeId)
VALUES
('1',5000,'USD','Nov',127,140,4700,300,6000,'716192');

INSERT INTO Employee_Salary_Details
(SalaryId,
MonthlySalary,
SalaryCurrency,
SalaryMonth,
TaxDeductions,
EmiDeductions,
BasicSalary,
Allowances,
TotalCTC,Employee_Company_Information_EmployeeId)
VALUES
('2',5000,'USD','Nov',127,140,4700,300,6000,'716192');

-- Select * from Employee_Company_Information;

INSERT INTO Employee_Salary_Details
(SalaryId,
MonthlySalary,
SalaryCurrency,
SalaryMonth,
TaxDeductions,
EmiDeductions,
BasicSalary,
Allowances,
TotalCTC,Employee_Company_Information_EmployeeId)
VALUES
('3',2000.45,'USD','Oct',110.60,140.45,4200.50,400.60,3600.50,'716193');

INSERT INTO Employee_Salary_Details
(SalaryId,
MonthlySalary,
SalaryCurrency,
SalaryMonth,
TaxDeductions,
EmiDeductions,
BasicSalary,
Allowances,
TotalCTC,Employee_Company_Information_EmployeeId)
VALUES
('4',2000.45,'USD','Oct',110.60,140.45,4200.50,400.60,3600.50,'716193');

INSERT INTO Employee_Salary_Details
(SalaryId,
MonthlySalary,
SalaryCurrency,
SalaryMonth,
TaxDeductions,
EmiDeductions,
BasicSalary,
Allowances,
TotalCTC,Employee_Company_Information_EmployeeId)
VALUES
('5',5500,'USD','Oct',170,140,4900,600,6600,'716194');

INSERT INTO Employee_Salary_Details
(SalaryId,
MonthlySalary,
SalaryCurrency,
SalaryMonth,
TaxDeductions,
EmiDeductions,
BasicSalary,
Allowances,
TotalCTC,Employee_Company_Information_EmployeeId)
VALUES
('6',5500,'USD','Oct',170,140,4900,600,6600,'716194');

INSERT INTO Employee_Salary_Details
(SalaryId,
MonthlySalary,
SalaryCurrency,
SalaryMonth,
TaxDeductions,
EmiDeductions,
BasicSalary,
Allowances,
TotalCTC,Employee_Company_Information_EmployeeId)
VALUES
('7',3700.34,'USD','Oct',90.00,100.00,3500.,200.20,4440.45,'716195');

INSERT INTO Employee_Salary_Details
(SalaryId,
MonthlySalary,
SalaryCurrency,
SalaryMonth,
TaxDeductions,
EmiDeductions,
BasicSalary,
Allowances,
TotalCTC,Employee_Company_Information_EmployeeId)
VALUES
('8',3700.34,'USD','Oct',90.00,100.00,3500.,200.20,4440.45,'716195');

Select * from Employee_Salary_Details;

-- Insert Statements for Employee_Previous_Work_Experience


INSERT INTO Employee_Previous_Work_Experience
(PreviousWorkExpId,
EmployerName,
Duration,
CompanyLocation,
StartDate,
EndDate,
ComapnyContactNumber,Employee_Company_Information_EmployeeId)
VALUES
('1','Barclays','2.8 YRS','India','2014-12-01','2017-07-28','9087689832','716192');

INSERT INTO Employee_Previous_Work_Experience
(PreviousWorkExpId,
EmployerName,
Duration,
CompanyLocation,
StartDate,
EndDate,
ComapnyContactNumber,Employee_Company_Information_EmployeeId)
VALUES
('2','Infosys','3.10 YRS','India','2014-10-02','2017-12-05','9734926187','716193');

INSERT INTO Employee_Previous_Work_Experience
(PreviousWorkExpId,
EmployerName,
Duration,
CompanyLocation,
StartDate,
EndDate,
ComapnyContactNumber,Employee_Company_Information_EmployeeId)
VALUES
('3','Amazon','3 YRS','India','2014-01-01','2017-01-01','9852340170','716194');

INSERT INTO Employee_Previous_Work_Experience
(PreviousWorkExpId,
EmployerName,
Duration,
CompanyLocation,
StartDate,
EndDate,
ComapnyContactNumber,Employee_Company_Information_EmployeeId)
VALUES
('4','N/A','N/A','N/A',null,null,'N/A','716195');

select * from Employee_Previous_Work_Experience;


-- Insert Statements for Employee_Personal_Information

-- Alter table Empoyee_Personal_Information rename to Employee_Personal_Information;

INSERT INTO Employee_Personal_Information
(EmployeePersonalInformationId,
FirstName,
MiddleName,
LastName,
DateOfBirth,
MobileNumber,
HomeNumber,
City,
State,
ZipCode,
Street,
Gender,
MaritialStatus,Employee_Company_Information_EmployeeId)
VALUES
('1','Robert','','John','1982-01-01','8976545362','0755246175','Boston','Massachusetts','02115','Germain Street','Male','Single','716192');

INSERT INTO Employee_Personal_Information
(EmployeePersonalInformationId,
FirstName,
MiddleName,
LastName,
DateOfBirth,
MobileNumber,
HomeNumber,
City,
State,
ZipCode,
Street,
Gender,
MaritialStatus,Employee_Company_Information_EmployeeId)
VALUES
('2','Alisa','Parker','Smith','1985-05-04','9067239156','6170371946','Boston','Massachusetts','02115','Henninway Street','Female','Married','716193');

INSERT INTO Employee_Personal_Information
(EmployeePersonalInformationId,
FirstName,
MiddleName,
LastName,
DateOfBirth,
MobileNumber,
HomeNumber,
City,
State,
ZipCode,
Street,
Gender,
MaritialStatus,Employee_Company_Information_EmployeeId)
VALUES
('3','Andrew','','Coyne','1980-08-02','7293658345','6178761935','Boston','Massachusetts','02115','Hungtington Avenue','Male','Married','716194');

INSERT INTO Employee_Personal_Information
(EmployeePersonalInformationId,
FirstName,
MiddleName,
LastName,
DateOfBirth,
MobileNumber,
HomeNumber,
City,
State,
ZipCode,
Street,
Gender,
MaritialStatus,Employee_Company_Information_EmployeeId)
VALUES
('4','Karin','Louis','Jones','1982-02-08','9046254826','9174356505','Boston','Massachusetts','02115','Clearway Street','Female','Single','716195');


Select * from Employee_Personal_Information;

-- Insert Statement for Employee_Department_Details

INSERT INTO Employee_Department_Details
(DepartmentId,
DepartmentName,
DepartmentType,
DepartmenrHead,
DeliveryManager,
Employee_Company_Information_EmployeeId)
VALUES
('1','FSADM1','Banking','Denis Louis','David Philps','716192');

INSERT INTO Employee_Department_Details
(DepartmentId,
DepartmentName,
DepartmentType,
DepartmenrHead,
DeliveryManager,
Employee_Company_Information_EmployeeId)
VALUES
('2','UKRBWS','Finance','Mike Denson','Jimmy Morgan','716193');

INSERT INTO Employee_Department_Details
(DepartmentId,
DepartmentName,
DepartmentType,
DepartmenrHead,
DeliveryManager,
Employee_Company_Information_EmployeeId)
VALUES
('3','FSADM2','Telecom','Mike Denson','Jimmy Morgan','716194');

INSERT INTO Employee_Department_Details
(DepartmentId,
DepartmentName,
DepartmentType,
DepartmenrHead,
DeliveryManager,
Employee_Company_Information_EmployeeId)
VALUES
('4','TELSTR','Telecom','Mike Denson','Jimmy Morgan','716195');

Select * from Employee_Department_Details;

-- Insert Statement for Project_Allocation_Details

INSERT INTO Project_Allocation_Details
(ProjectCode,
StartDate,
EndDate,
Employee_Department_Details_DepartmentId,
Employee_Company_Information_EmployeeId)
VALUES
('123','2015-01-02','2018-01-02','1','716192');


INSERT INTO Project_Allocation_Details
(ProjectCode,
StartDate,
EndDate,
Employee_Department_Details_DepartmentId,
Employee_Company_Information_EmployeeId)
VALUES
('456','2013-01-02','2019-01-02','2','716193');

INSERT INTO Project_Allocation_Details
(ProjectCode,
StartDate,
EndDate,
Employee_Department_Details_DepartmentId,
Employee_Company_Information_EmployeeId)
VALUES
('789','2015-01-02','2020-01-02','3','716194');

INSERT INTO Project_Allocation_Details
(ProjectCode,
StartDate,
EndDate,
Employee_Department_Details_DepartmentId,
Employee_Company_Information_EmployeeId)
VALUES
('345','2013-01-02','2023-01-02','4','716195');


INSERT INTO Project_Allocation_Details
(ProjectCode,
StartDate,
EndDate,
Employee_Department_Details_DepartmentId,
Employee_Company_Information_EmployeeId)
VALUES
('890','2013-01-02','2023-01-02','4','716195');


INSERT INTO Project_Allocation_Details
(ProjectCode,
StartDate,
EndDate,
Employee_Department_Details_DepartmentId,
Employee_Company_Information_EmployeeId)
VALUES
('321','2015-01-02','2018-01-02','2','716192');

Select * from Project_Allocation_Details;

-- Stored Procedures for Deleting the record from the Employee_Company,Information table

DELIMITER %%
CREATE PROCEDURE Delete_Employee(IN EmployeeId_Delete VARCHAR(6)) 
BEGIN 
	-- DECLARE EmployeeId_Delete_New VARCHAR(6);
	START TRANSACTION;

    DELETE FROM Employee_Leave_Details 
	WHERE Employee_Leave_Details.Employee_Company_Information_EmployeeId = EmployeeId_Delete;

	DELETE FROM Employee_Timesheet_Information 
	WHERE Employee_Timesheet_Information.Employee_Company_Information_EmployeeId = EmployeeId_Delete;

	DELETE FROM Employee_Performance_Information 
	WHERE Employee_Performance_Information.Employee_Company_Information_EmployeeId = EmployeeId_Delete;

	DELETE FROM Employee_Personal_Information 
	WHERE Employee_Personal_Information.Employee_Company_Information_EmployeeId = EmployeeId_Delete;

	DELETE FROM Employee_Salary_Details 
	WHERE Employee_Salary_Details.Employee_Company_Information_EmployeeId = EmployeeId_Delete;

	DELETE FROM Project_Allocation_Details
	WHERE Project_Allocation_Details.Employee_Company_Information_EmployeeId = EmployeeId_Delete;

	DELETE FROM Employee_Previous_Work_Experience 
	WHERE Employee_Previous_Work_Experience.Employee_Company_Information_EmployeeId = EmployeeId_Delete;

	DELETE FROM Employee_Department_Details
	WHERE Employee_Department_Details.Employee_Company_Information_EmployeeId = EmployeeId_Delete;

	DELETE FROM Employee_Company_Information
	WHERE Employee_Company_Information.EmployeeId = EmployeeId_Delete;
	
	COMMIT;

END %%
DELIMITER ; 

-- Drop procedure Delete_Employee;

Call Delete_Employee ('716194');

Select * from Employee_Company_Information;

-- Trigger for Update in Ex_Employee_Information

DELIMITER %%
CREATE TRIGGER Audit_delete_Employee AFTER DELETE on Employee_Company_Information
FOR EACH ROW
BEGIN

Insert Into  Ex_Employee_Information(EmployeeId,DateOfLeaving) value(old.EmployeeId,sysdate());

END %%
DELIMITER ; 
     
Select * from Ex_Employee_Information;

-- Drop trigger Audit_delete_Employee;

-- Stored Procedure for Applying leaves

DELIMITER %%
CREATE PROCEDURE Update_Leave_Details(IN EmployeeId_Update VARCHAR(6),IN Sick_Leaves INTEGER,IN Annual_Leaves INTEGER) 
BEGIN 
	Declare AvailableSickLeavesUpdate INTEGER;
	Declare AvailableLeavesUpdate INTEGER;
	Declare SickLeavesDebitedUpdate INTEGER;
	Declare AvailableLeavesDebitedUpdate INTEGER;
	Select @AvailableSickLeaves := AvailableSickLeaves from Employee_Leave_Details WHERE Employee_Company_Information_EmployeeId = EmployeeId_Update;
	Select @AvailableAnnualLeaves := AvailableLeaves from Employee_Leave_Details WHERE Employee_Company_Information_EmployeeId = EmployeeId_Update;
	Select @SickLeavesDebited := SickLeavesDebited from Employee_Leave_Details WHERE Employee_Company_Information_EmployeeId = EmployeeId_Update;
	Select @TotalLeavesDebited := TotalLeavesDebited from Employee_Leave_Details WHERE Employee_Company_Information_EmployeeId = EmployeeId_Update;

	START TRANSACTION;

	SET AvailableSickLeavesUpdate = @AvailableSickLeaves - Sick_Leaves;
    SET AvailableLeavesUpdate = @AvailableAnnualLeaves - Annual_Leaves;
	SET SickLeavesDebitedUpdate = @SickLeavesDebited + Sick_Leaves;
	SET AvailableLeavesDebitedUpdate = @TotalLeavesDebited + Annual_Leaves;

	Update Employee_Leave_Details
	Set AvailableLeaves = AvailableLeavesUpdate
    , TotalLeavesDebited = AvailableLeavesDebitedUpdate
    , AvailableSickLeaves = AvailableSickLeavesUpdate,
	SickLeavesDebited = SickLeavesDebitedUpdate
	Where Employee_Company_Information_EmployeeId =  EmployeeId_Update;

	COMMIT;

	select * from Employee_Leave_Details;

END %%
DELIMITER ; 

Call Update_Leave_Details ('716193',3,2);

-- Drop procedure Update_Leave_Details;

-- Stored Procedure to calculate the Increment

DELIMITER %%
CREATE PROCEDURE Calculate_Increment(IN EmployeeId_Update VARCHAR(6),IN Increment Decimal(6,2), IN salaryMonth varchar(6)) 
BEGIN 

	Declare UpdateBasicSalary Decimal(14,2);
	Declare UpdateAllowances Decimal(14,2);
	Declare UpdateMonthlySalary Decimal(14,2);
	Declare UpdatedCtc Decimal(14,2);
	-- Declare UpdateSalaryMonth Varchar(6);
	
	Select @basicSalary := BasicSalary from Employee_Salary_Details where Employee_Company_Information_EmployeeId = EmployeeId_Update;
	Select @allowances := Allowances from Employee_Salary_Details where Employee_Company_Information_EmployeeId = EmployeeId_Update;
	Select @taxDeductions := TaxDeductions from Employee_Salary_Details where Employee_Company_Information_EmployeeId = EmployeeId_Update; 
	Select @emiDeductions := EmiDeductions from Employee_Salary_Details where Employee_Company_Information_EmployeeId = EmployeeId_Update;
	Select @monthlySalary := MonthlySalary from Employee_Salary_Details where Employee_Company_Information_EmployeeId = EmployeeId_Update;
	Select @Salary_Month := SalaryMonth from Employee_Salary_Details where Employee_Company_Information_EmployeeId = EmployeeId_Update 
				AND SalaryMonth = salaryMonth;

	START TRANSACTION;

	SET UpdateBasicSalary = @basicSalary * Increment;
    SET UpdateAllowances = @allowances * Increment;
	SET UpdateMonthlySalary = UpdateBasicSalary + @taxDeductions + UpdateAllowances + @emiDeductions;
	SET UpdatedCtc = UpdateMonthlySalary * 12;
	-- SET UpdateSalaryMonth = salaryMonth;
	SET salaryMonth = @Salary_Month;

	Update Employee_Salary_Details
	Set BasicSalary = UpdateBasicSalary
    , Allowances = UpdateAllowances
    , MonthlySalary = UpdateMonthlySalary,
	TotalCTC = UpdatedCtc
	Where Employee_Salary_Details.SalaryMonth = salaryMonth AND Employee_Salary_Details.Employee_Company_Information_EmployeeId =  EmployeeId_Update;

	COMMIT;

END%%
DELIMITER ;

-- Will take the paramters as employeeid, increment and month
Call Calculate_Increment ('716195',2.0,'Nov');

Select * from Employee_Salary_Details;

-- Drop procedure Calculate_Increment;

-- Trigger for Updating the increment details in another table for Backup

DELIMITER %%
CREATE TRIGGER Audit_Increment_Details AFTER UPDATE on Employee_Salary_Details
FOR EACH ROW
BEGIN

Insert Into  Audit_Employee_Salary_Details(OldBasicSalary,OldTotalCTC,EmployeeId,SalaryId,OldMonthlySalary,OldAllowances) 
value(old.BasicSalary,old.TotalCTC,old.Employee_Company_Information_EmployeeId,old.SalaryId,old.MonthlySalary,old.Allowances);

END %%
DELIMITER ; 

-- drop trigger Audit_Increment_Details;

Select * from Audit_Employee_Salary_Details;

-- Views For Displaying the Data from Employee_Company_Information and Employee_Personal_Information 

Create View Employee_Info
as 
Select Employee_Company_Information.EmployeeId as Employee_Id,
	Employee_Personal_Information.FirstName as First_Name,   
    Employee_Personal_Information.MiddleName as Middle_Name,  
	Employee_Personal_Information.LastName as Last_Name,          
	Employee_Personal_Information.DateOfBirth as Date_Of_Birth,
	Employee_Personal_Information.HomeNumber as Home_Number,
	Employee_Personal_Information.Gender as Gender,
	Employee_Personal_Information.MaritialStatus as Maritial_Status,
	Employee_Company_Information.Department as Department,
	Employee_Company_Information.DateOfJoining as Joining_Date,
	Employee_Company_Information.Designation as Designation,
	Employee_Company_Information.ProjectAllocationCode as Project_Code,
	Employee_Company_Information.OfficeEmailId as Email_Id,
	Employee_Company_Information.OfficeLocation as Location,
	Employee_Performance_Information.Rating as Ratings,
	Employee_Performance_Information.EvaluationManager as Evaluation_Manager,
	Employee_Performance_Information.ApprovalManager as Approval_Manager
from Employee_Personal_Information 
inner join Employee_Company_Information
    on Employee_Company_Information.EmployeeId=Employee_Personal_Information.Employee_Company_Information_EmployeeId inner join Employee_Performance_Information
on Employee_Company_Information.EmployeeId = Employee_Performance_Information.Employee_Company_Information_EmployeeId;

-- Select from Employee_Info
Select * from Employee_Info;

-- Drop Employee_Info
-- Drop view Employee_Info;

-- Stored procedure for Search Employee

DELIMITER %%
CREATE PROCEDURE Search_Employee(IN EmployeeId_Search VARCHAR(6)) 
BEGIN 
	-- DECLARE EmployeeId_Delete_New VARCHAR(6);
	START TRANSACTION;
		
	Select * from Employee_Info WHERE Employee_Id = EmployeeId_Search;
	
	COMMIT;

END %%
DELIMITER ; 

-- Drop Procedure Search_Employee;

Call Search_Employee('716192');

-- Views for Displaying the Project Details and Timesheet Information

Create View Project_Timesheet_Info
as 
Select Project_Allocation_Details.Employee_Company_Information_EmployeeId as Employee_Id,
	Employee_Timesheet_Information.TimeSheetId as Time_Sheet_Id,
	Project_Allocation_Details.ProjectCode as Project_Allocated,   
    Project_Allocation_Details.StartDate as Project_StartDate,  
	Project_Allocation_Details.EndDate as Project_EndDate,          
	Project_Allocation_Details.Employee_Department_Details_DepartmentId as Department,
	Employee_Timesheet_Information.TotalHours as Total_Working_Hours_Daily,
	Employee_Timesheet_Information.TaskStartDate as Task_StartDate,
	Employee_Timesheet_Information.TaskEndDate as Task_EndDate,
	Employee_Timesheet_Information.TaskDescription as Task,
	Employee_Timesheet_Information.ManagerName as Manager_Name
from Project_Allocation_Details 
inner join Employee_Timesheet_Information
    on Project_Allocation_Details.Employee_Company_Information_EmployeeId = Employee_Timesheet_Information.Employee_Company_Information_EmployeeId;

-- Select from Project_Timesheet_Info
Select * from Project_Timesheet_Info;

-- Drop Project_Timesheet_Info
 -- Drop view Project_Timesheet_Info;

-- Stored procedure for add Employee

DELIMITER %%
CREATE PROCEDURE Add_Employee(IN EmployeeId_Add VARCHAR(6),IN Department_Add VARCHAR(6), IN JoiningDate_Add timestamp,
IN Designation_Add varchar(30), In Project_Add Varchar(15), IN Office_Add Varchar(20), IN State_Add varchar(30), IN ZipCode_Add varchar(5),
iN OfficeEmail varchar(30),IN OfficeContactNumber_Add varchar(10)) 
BEGIN 
	-- DECLARE EmployeeId_Delete_New VARCHAR(6);
	START TRANSACTION;
		
	
		INSERT INTO Employee_Company_Information VALUES
(EmployeeId_Add,Department_Add,JoiningDate_Add,Designation_Add,Project_Add,Office_Add,State_Add,ZipCode_Add,OfficeEmail,OfficeContactNumber_Add);

	
	COMMIT;

END %%
DELIMITER ; 

-- Calling of Add Employee
Call Add_Employee('716199','FSADM2',sysdate(),'Associate','BUK','Boston','Massachusetts','02115','frt@bnj@Barclays.com','7628495624');

Select * from Employee_Company_Information;

-- Drop of Add_Employee
-- Drop procedure Add_Employee;

-- Stored Procedures for Deleting the record from the Employee_Department_Details table

DELIMITER %%
CREATE PROCEDURE Delete_Employee_Department(IN EmployeeId_Delete VARCHAR(6)) 
BEGIN 
	-- DECLARE EmployeeId_Delete_New VARCHAR(6);
	START TRANSACTION;

    DELETE FROM Project_Allocation_Details 
	WHERE Project_Allocation_Details.Employee_Company_Information_EmployeeId = EmployeeId_Delete;

	DELETE FROM Employee_Department_Details 
	WHERE Employee_Department_Details.Employee_Company_Information_EmployeeId = EmployeeId_Delete;
	
	COMMIT;

END %%
DELIMITER ; 

-- Drop procedure Delete_Employee_Department;

Call Delete_Employee_Department ('716195');

select * from project_allocation_details;
select * from Employee_department_Details;

-- Trigger to Enter the data into the Department Audit table on deletion of record from the Department table.

DELIMITER %%
CREATE TRIGGER Audit_Department_Details AFTER DELETE on Employee_Department_Details
FOR EACH ROW
BEGIN

Insert Into  Audit_Employee_Department_Details(EmployeeId,DepartmentName,DepartmentId,DepartmentType,DepartmentHead,DeliveryManager) 
value(old.Employee_Company_Information_EmployeeId,old.DepartmentName,old.DepartmentId,old.DepartmentType,old.DepartmenrHead,old.DeliveryManager);

END %%
DELIMITER ; 

select * from Audit_Employee_Department_Details;

-- Drop trigger Audit_Department_Details;

-- GRANT and REVOKE privileges to different user

use Final_Project;

GRANT SELECT on Final_Project .* to newuser1@localhost identified by "shubhi@123";

REVOKE ALL privileges on Final_Project .* FROM newuser1@localhost;

Flush privileges;